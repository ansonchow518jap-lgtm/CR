
# CruiseReady Dashboard — One-File Deploy

This ZIP includes a single `index.html` that contains the CruiseReady dashboard (React via CDN).
You can deploy it as a static site and then paste the public URL into Miro for an interactive embed.

## Fast hosting options

### Netlify Drop (drag & drop)
1. Visit https://app.netlify.com/drop
2. Drag `index.html` onto the page.
3. Copy the public URL and paste it into Miro.

### Vercel
1. Create a new project → "Other / Static".
2. Upload this ZIP (or a folder with `index.html`). 
3. Deploy and copy the URL for Miro.

### GitHub Pages
1. Create a repository and add `index.html`.
2. Enable Pages in Settings → Pages (deploy from main branch).
3. Use the Pages URL in Miro.

## Notes
- No build step required. React and Babel are loaded via CDN.
- If you later move to production, replace the Babel/UMD setup with a proper build (Vite/Next).
